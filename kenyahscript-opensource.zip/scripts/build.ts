import { execFileSync } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import * as esbuild from 'esbuild';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const rootDir = path.resolve(__dirname, '..');
const distDir = path.join(rootDir, 'dist');

fs.rmSync(distDir, { recursive: true, force: true });
fs.mkdirSync(distDir, { recursive: true });

esbuild.buildSync({
  entryPoints: [path.join(rootDir, 'src', 'npmEntry.ts')],
  outfile: path.join(distDir, 'index.js'),
  bundle: true,
  format: 'esm',
  platform: 'node',
  target: 'node18',
  sourcemap: false,
  minify: false,
});

esbuild.buildSync({
  entryPoints: [path.join(rootDir, 'bin', 'kny.ts')],
  outfile: path.join(distDir, 'cli.js'),
  bundle: true,
  format: 'esm',
  platform: 'node',
  target: 'node18',
  banner: {
    js: '#!/usr/bin/env node',
  },
  sourcemap: false,
  minify: false,
});
fs.chmodSync(path.join(distDir, 'cli.js'), 0o755);

const tscBin = path.join(rootDir, 'node_modules', '.bin', 'tsc');
const tmpTsConfigPath = path.join(rootDir, '.tsconfig.build.json');
fs.writeFileSync(
  tmpTsConfigPath,
  JSON.stringify(
    {
      compilerOptions: {
        target: 'ES2022',
        module: 'ESNext',
        moduleResolution: 'bundler',
        lib: ['ES2022'],
        types: ['node'],
        declaration: true,
        emitDeclarationOnly: true,
        outDir: './dist/types',
        rootDir: './src',
        skipLibCheck: true,
        strict: true,
      },
      include: [
        'src/npmEntry.ts',
        'src/transpiler.ts',
        'src/utils/formatKenyah.ts',
      ],
    },
    null,
    2
  ),
  'utf8'
);

try {
  execFileSync(tscBin, ['-p', tmpTsConfigPath], {
    cwd: rootDir,
    stdio: 'pipe',
  });
} finally {
  fs.rmSync(tmpTsConfigPath, { force: true });
}

fs.writeFileSync(
  path.join(distDir, 'index.d.ts'),
  "export * from './types/npmEntry.js';\n",
  'utf8'
);

console.log('Built kenyahscript dist/ bundle successfully.');
