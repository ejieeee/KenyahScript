const BINARY_OPS = new Set([
  '=',
  '==',
  '===',
  '!=',
  '!==',
  '<=',
  '>=',
  '&&',
  '||',
  '+=',
  '-=',
  '*=',
  '/=',
  '=>',
  '+',
  '-',
  '*',
  '/',
  '%',
  '<',
  '>',
]);

const CONTROL_SPACE_BEFORE_PAREN = new Set(['boq', 'lain', 'ulang', 'selama', 'if', 'for', 'while']);

const MULTI_CHAR_OPS = [
  '===',
  '!==',
  '==',
  '!=',
  '<=',
  '>=',
  '&&',
  '||',
  '++',
  '--',
  '+=',
  '-=',
  '*=',
  '/=',
  '=>',
  '?.',
];

interface FormatToken {
  kind: 'word' | 'number' | 'string' | 'comment' | 'op' | 'punct';
  value: string;
}

function isIdentStart(ch: string): boolean {
  return (
    (ch >= 'a' && ch <= 'z') ||
    (ch >= 'A' && ch <= 'Z') ||
    ch === '_' ||
    ch === '$'
  );
}

function isIdentPart(ch: string): boolean {
  return isIdentStart(ch) || (ch >= '0' && ch <= '9');
}

function isDigit(ch: string): boolean {
  return ch >= '0' && ch <= '9';
}

function tokenizeLine(
  line: string,
  inBlockComment: boolean
): { tokens: FormatToken[]; inBlockComment: boolean } {
  const tokens: FormatToken[] = [];
  let i = 0;

  if (inBlockComment) {
    const endIdx = line.indexOf('*/');
    if (endIdx === -1) {
      return {
        tokens: [{ kind: 'comment', value: line.trim() }],
        inBlockComment: true,
      };
    }
    tokens.push({ kind: 'comment', value: line.slice(0, endIdx + 2).trim() });
    i = endIdx + 2;
    inBlockComment = false;
  }

  while (i < line.length) {
    const ch = line[i];

    if (ch === ' ' || ch === '\t') {
      i++;
      continue;
    }

    // Single-line comment
    if (ch === '/' && line[i + 1] === '/') {
      tokens.push({ kind: 'comment', value: line.slice(i).trimEnd() });
      break;
    }

    // Block comment
    if (ch === '/' && line[i + 1] === '*') {
      const endIdx = line.indexOf('*/', i + 2);
      if (endIdx === -1) {
        tokens.push({ kind: 'comment', value: line.slice(i).trimEnd() });
        inBlockComment = true;
        break;
      }
      tokens.push({ kind: 'comment', value: line.slice(i, endIdx + 2) });
      i = endIdx + 2;
      continue;
    }

    // String / template literal
    if (ch === '"' || ch === "'" || ch === '`') {
      const quote = ch;
      const start = i;
      i++;
      while (i < line.length) {
        if (line[i] === '\\') {
          i += Math.min(2, line.length - i);
          continue;
        }
        if (line[i] === quote) {
          i++;
          break;
        }
        i++;
      }
      tokens.push({ kind: 'string', value: line.slice(start, i) });
      continue;
    }

    // Identifiers & keywords
    if (isIdentStart(ch)) {
      const start = i;
      i++;
      while (i < line.length && isIdentPart(line[i])) i++;
      tokens.push({ kind: 'word', value: line.slice(start, i) });
      continue;
    }

    // Numbers
    if (isDigit(ch)) {
      const start = i;
      i++;
      while (i < line.length && (isDigit(line[i]) || line[i] === '.')) i++;
      tokens.push({ kind: 'number', value: line.slice(start, i) });
      continue;
    }

    // Multi-char operators
    const multi = MULTI_CHAR_OPS.find((op) => line.startsWith(op, i));
    if (multi) {
      tokens.push({ kind: multi === '?.' ? 'punct' : 'op', value: multi });
      i += multi.length;
      continue;
    }

    // Single char op or punct
    if (BINARY_OPS.has(ch) || ch === '!' || ch === '?') {
      tokens.push({ kind: 'op', value: ch });
    } else {
      tokens.push({ kind: 'punct', value: ch });
    }
    i++;
  }

  return { tokens, inBlockComment };
}

function isUnaryPosition(prev: FormatToken | undefined): boolean {
  if (!prev) return true;
  if (prev.kind === 'op' && prev.value !== '++' && prev.value !== '--') return true;
  if (prev.kind === 'punct' && ['(', '[', '{', ',', ';', ':'].includes(prev.value)) {
    return true;
  }
  if (prev.kind === 'word' && (prev.value === 'ulek' || prev.value === 'return')) {
    return true;
  }
  return false;
}

function joinFormattedTokens(tokens: FormatToken[]): string {
  let out = '';
  for (let idx = 0; idx < tokens.length; idx++) {
    const curr = tokens[idx];
    const prev = idx > 0 ? tokens[idx - 1] : undefined;

    if (!prev) {
      out += curr.value;
      continue;
    }

    let needSpace = false;

    if (curr.kind === 'comment') {
      needSpace = true;
    } else if (prev.value === '.' || prev.value === '?.' || curr.value === '.' || curr.value === '?.') {
      needSpace = false;
    } else if (curr.value === ',' || curr.value === ';' || curr.value === ':' || curr.value === ')' || curr.value === ']') {
      needSpace = false;
    } else if (prev.value === '(' || prev.value === '[' || prev.value === '!') {
      needSpace = false;
    } else if (curr.value === '++' || curr.value === '--') {
      needSpace = false;
    } else if (prev.value === '++' || prev.value === '--') {
      needSpace = curr.kind === 'word' || curr.kind === 'number';
    } else if (prev.value === ',' || prev.value === ';' || prev.value === ':') {
      needSpace = true;
    } else if (prev.value === '{' && curr.value !== '}') {
      needSpace = true;
    } else if (curr.value === '}' && prev.value !== '{') {
      needSpace = true;
    } else if (curr.value === '{') {
      needSpace = true;
    } else if (prev.value === '}') {
      needSpace = true;
    } else if (curr.value === '(') {
      needSpace = prev.kind === 'word' && CONTROL_SPACE_BEFORE_PAREN.has(prev.value);
    } else if (curr.kind === 'op' && BINARY_OPS.has(curr.value)) {
      if ((curr.value === '-' || curr.value === '+') && isUnaryPosition(prev)) {
        needSpace = prev.kind === 'word' || prev.kind === 'op' || prev.value === ',' || prev.value === ';';
      } else {
        needSpace = true;
      }
    } else if (prev.kind === 'op' && BINARY_OPS.has(prev.value)) {
      const prevPrev = idx >= 2 ? tokens[idx - 2] : undefined;
      if ((prev.value === '-' || prev.value === '+') && isUnaryPosition(prevPrev)) {
        needSpace = false;
      } else {
        needSpace = true;
      }
    } else if (prev.value === '?' || curr.value === '?') {
      needSpace = true;
    } else if (
      (prev.kind === 'word' || prev.kind === 'number' || prev.kind === 'string') &&
      (curr.kind === 'word' || curr.kind === 'number' || curr.kind === 'string')
    ) {
      needSpace = true;
    }

    out += (needSpace ? ' ' : '') + curr.value;
  }
  return out;
}

export function formatKenyahScript(source: string): string {
  if (!source.trim()) return '';

  const rawLines = source.replace(/\r\n|\r/g, '\n').split('\n');
  const formattedLines: string[] = [];
  let indentLevel = 0;
  let inBlockComment = false;
  let lastWasBlank = false;

  for (const rawLine of rawLines) {
    const trimmed = rawLine.trim();

    if (trimmed === '') {
      if (formattedLines.length > 0 && !lastWasBlank) {
        formattedLines.push('');
        lastWasBlank = true;
      }
      continue;
    }

    lastWasBlank = false;
    const wasInBlockComment = inBlockComment;
    const parsed = tokenizeLine(rawLine, inBlockComment);
    inBlockComment = parsed.inBlockComment;

    if (wasInBlockComment) {
      formattedLines.push(`${'  '.repeat(indentLevel)}${trimmed}`);
      continue;
    }

    const tokens = parsed.tokens;
    const lineBody = joinFormattedTokens(tokens);

    const startsWithClosingBrace =
      tokens.length > 0 && tokens[0].kind === 'punct' && tokens[0].value === '}';

    const currentIndent = startsWithClosingBrace
      ? Math.max(0, indentLevel - 1)
      : indentLevel;

    formattedLines.push(`${'  '.repeat(currentIndent)}${lineBody}`);

    let opens = 0;
    let closes = 0;
    for (const tok of tokens) {
      if (tok.kind === 'punct') {
        if (tok.value === '{') opens++;
        if (tok.value === '}') closes++;
      }
    }
    indentLevel = Math.max(0, indentLevel + opens - closes);
  }

  while (formattedLines.length > 0 && formattedLines[formattedLines.length - 1] === '') {
    formattedLines.pop();
  }

  return formattedLines.join('\n');
}
