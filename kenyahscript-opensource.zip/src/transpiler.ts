export const KEYWORD_MAP: Readonly<Record<string, string>> = {
  ti: 'let',
  tetap: 'const',
  desimal: 'let',
  gayeng: 'function',
  ulek: 'return',
  boq: 'if',
  lain: 'else',
  ulang: 'for',
  selama: 'while',
  tulis: 'console.log',
  teneng: 'true',
  bohong: 'false',
  sala: 'false',
  kosong: 'null',
};

export interface TranspiledToken {
  type:
    | 'keyword'
    | 'identifier'
    | 'property'
    | 'string'
    | 'comment'
    | 'number'
    | 'punctuation'
    | 'whitespace';
  raw: string;
  output: string;
  line: number;
  column: number;
}

export interface TranspileAnalysis {
  code: string;
  tokens: TranspiledToken[];
  stats: {
    keywordsReplaced: number;
    preservedProperties: number;
    stringsCount: number;
    commentsCount: number;
    lines: number;
  };
}

export type TranspilerProblemNature =
  | 'UnclosedStringLiteral'
  | 'UnclosedTemplateLiteral'
  | 'UnclosedBlockComment'
  | 'UnclosedTemplateExpression'
  | 'InvalidNumberLiteral'
  | 'InvalidInputType'
  | 'SyntaxError'
  | 'UnexpectedTranspilerError';

export class KenyahSyntaxError extends SyntaxError {
  line: number;
  column: number;
  nature: TranspilerProblemNature;
  filename?: string;

  constructor(
    message: string,
    line: number,
    column: number,
    filename?: string,
    nature: TranspilerProblemNature = 'SyntaxError'
  ) {
    const loc = filename ? `${filename}:${line}:${column}` : `${line}:${column}`;
    super(`${message} (${loc})`);
    this.name = 'KenyahSyntaxError';
    this.line = line;
    this.column = column;
    this.nature = nature;
    this.filename = filename;
  }
}

export class KenyahTranspilerError extends Error {
  line: number;
  column: number;
  nature: TranspilerProblemNature;
  filename?: string;

  constructor(
    message: string,
    line = 1,
    column = 1,
    nature: TranspilerProblemNature = 'UnexpectedTranspilerError',
    filename?: string
  ) {
    const loc = filename ? `${filename}:${line}:${column}` : `${line}:${column}`;
    super(`${message} (${loc})`);
    this.name = 'KenyahTranspilerError';
    this.line = line;
    this.column = column;
    this.nature = nature;
    this.filename = filename;
  }
}

function isIdentStart(ch: string): boolean {
  return (
    (ch >= 'a' && ch <= 'z') ||
    (ch >= 'A' && ch <= 'Z') ||
    ch === '_' ||
    ch === '$'
  );
}

function isIdentPart(ch: string): boolean {
  return (
    isIdentStart(ch) ||
    (ch >= '0' && ch <= '9')
  );
}

function isDigit(ch: string): boolean {
  return ch >= '0' && ch <= '9';
}

function isWhitespace(ch: string): boolean {
  return ch === ' ' || ch === '\t' || ch === '\n' || ch === '\r' || ch === '\f' || ch === '\v';
}

function peekNextSignificantChar(source: string, startIndex: number): string {
  let i = startIndex;
  while (i < source.length) {
    const ch = source[i];
    if (isWhitespace(ch)) {
      i++;
      continue;
    }
    if (ch === '/' && source[i + 1] === '/') {
      i += 2;
      while (i < source.length && source[i] !== '\n') i++;
      continue;
    }
    if (ch === '/' && source[i + 1] === '*') {
      i += 2;
      while (i < source.length && !(source[i] === '*' && source[i + 1] === '/')) {
        i++;
      }
      i += 2;
      continue;
    }
    return ch;
  }
  return '';
}

function scanChunk(
  source: string,
  startIndex: number,
  startLine: number,
  startCol: number,
  stopAtClosingBrace: boolean,
  filename?: string
): {
  code: string;
  tokens: TranspiledToken[];
  endIndex: number;
  endLine: number;
  endCol: number;
  keywordsReplaced: number;
  preservedProperties: number;
  stringsCount: number;
  commentsCount: number;
} {
  let i = startIndex;
  let line = startLine;
  let col = startCol;
  let out = '';
  const tokens: TranspiledToken[] = [];
  let keywordsReplaced = 0;
  let preservedProperties = 0;
  let stringsCount = 0;
  let commentsCount = 0;

  let prevSigToken = '';
  let braceDepth = 0;

  const advance = (count = 1) => {
    for (let k = 0; k < count; k++) {
      if (source[i] === '\n') {
        line++;
        col = 1;
      } else {
        col++;
      }
      i++;
    }
  };

  while (i < source.length) {
    const ch = source[i];

    if (stopAtClosingBrace && ch === '}' && braceDepth === 0) {
      break;
    }

    // Whitespace
    if (isWhitespace(ch)) {
      const tokLine = line;
      const tokCol = col;
      const start = i;
      while (i < source.length && isWhitespace(source[i])) {
        advance();
      }
      const raw = source.slice(start, i);
      out += raw;
      tokens.push({ type: 'whitespace', raw, output: raw, line: tokLine, column: tokCol });
      continue;
    }

    // Single-line comment
    if (ch === '/' && source[i + 1] === '/') {
      const tokLine = line;
      const tokCol = col;
      const start = i;
      advance(2);
      while (i < source.length && source[i] !== '\n') {
        advance();
      }
      const raw = source.slice(start, i);
      out += raw;
      commentsCount++;
      tokens.push({ type: 'comment', raw, output: raw, line: tokLine, column: tokCol });
      continue;
    }

    // Multi-line comment
    if (ch === '/' && source[i + 1] === '*') {
      const tokLine = line;
      const tokCol = col;
      const start = i;
      advance(2);
      let closed = false;
      while (i < source.length) {
        if (source[i] === '*' && source[i + 1] === '/') {
          advance(2);
          closed = true;
          break;
        }
        advance();
      }
      if (!closed) {
        throw new KenyahSyntaxError(
          'Komentar blok (/* ... */) belum ditutup',
          tokLine,
          tokCol,
          filename,
          'UnclosedBlockComment'
        );
      }
      const raw = source.slice(start, i);
      out += raw;
      commentsCount++;
      tokens.push({ type: 'comment', raw, output: raw, line: tokLine, column: tokCol });
      continue;
    }

    // Single or double-quoted string literal
    if (ch === '"' || ch === "'") {
      const quote = ch;
      const tokLine = line;
      const tokCol = col;
      const start = i;
      advance();
      let closed = false;

      while (i < source.length) {
        const c = source[i];
        if (c === '\\') {
          advance();
          if (i >= source.length) {
            throw new KenyahSyntaxError(
              'String literal tidak ditutup setelah karakter escape',
              tokLine,
              tokCol,
              filename,
              'UnclosedStringLiteral'
            );
          }
          if (source[i] === '\r' && source[i + 1] === '\n') {
            advance(2);
          } else {
            advance();
          }
          continue;
        }
        if (c === '\n' || c === '\r') {
          throw new KenyahSyntaxError(
            'String literal tidak ditutup sebelum akhir baris',
            tokLine,
            tokCol,
            filename,
            'UnclosedStringLiteral'
          );
        }
        if (c === quote) {
          advance();
          closed = true;
          break;
        }
        advance();
      }

      if (!closed) {
        throw new KenyahSyntaxError(
          `String literal (${quote}...${quote}) belum ditutup`,
          tokLine,
          tokCol,
          filename,
          'UnclosedStringLiteral'
        );
      }

      const raw = source.slice(start, i);
      out += raw;
      stringsCount++;
      prevSigToken = raw;
      tokens.push({ type: 'string', raw, output: raw, line: tokLine, column: tokCol });
      continue;
    }

    // Template literal `...${expr}...`
    if (ch === '`') {
      const tokLine = line;
      const tokCol = col;
      const start = i;
      advance();
      let tplOut = '`';
      let closed = false;

      while (i < source.length) {
        const c = source[i];
        if (c === '\\') {
          tplOut += c;
          advance();
          if (i >= source.length) {
            throw new KenyahSyntaxError(
              'Template literal tidak ditutup setelah escape',
              tokLine,
              tokCol,
              filename,
              'UnclosedTemplateLiteral'
            );
          }
          tplOut += source[i];
          advance();
          continue;
        }
        if (c === '`') {
          tplOut += '`';
          advance();
          closed = true;
          break;
        }
        if (c === '$' && source[i + 1] === '{') {
          tplOut += '${';
          advance(2);
          const nested = scanChunk(source, i, line, col, true, filename);
          tplOut += nested.code;
          keywordsReplaced += nested.keywordsReplaced;
          preservedProperties += nested.preservedProperties;
          stringsCount += nested.stringsCount;
          commentsCount += nested.commentsCount;
          i = nested.endIndex;
          line = nested.endLine;
          col = nested.endCol;
          if (i >= source.length || source[i] !== '}') {
            throw new KenyahSyntaxError(
              'Ekspresi ${...} di dalam template literal tidak ditutup',
              tokLine,
              tokCol,
              filename,
              'UnclosedTemplateExpression'
            );
          }
          tplOut += '}';
          advance();
          continue;
        }
        tplOut += c;
        advance();
      }

      if (!closed) {
        throw new KenyahSyntaxError(
          'Template literal (`...`) belum ditutup',
          tokLine,
          tokCol,
          filename,
          'UnclosedTemplateLiteral'
        );
      }

      const raw = source.slice(start, i);
      out += tplOut;
      stringsCount++;
      prevSigToken = raw;
      tokens.push({ type: 'string', raw, output: tplOut, line: tokLine, column: tokCol });
      continue;
    }

    // Identifier / Keyword
    if (isIdentStart(ch)) {
      const tokLine = line;
      const tokCol = col;
      const start = i;
      while (i < source.length && isIdentPart(source[i])) {
        advance();
      }
      const raw = source.slice(start, i);
      const isAfterDot = prevSigToken === '.' || prevSigToken === '?.';
      const nextChar = peekNextSignificantChar(source, i);
      const isObjectKey =
        (prevSigToken === '{' || prevSigToken === ',') && nextChar === ':';

      if (isAfterDot || isObjectKey) {
        out += raw;
        if (isAfterDot && Object.prototype.hasOwnProperty.call(KEYWORD_MAP, raw)) {
          preservedProperties++;
        }
        prevSigToken = raw;
        tokens.push({
          type: isAfterDot ? 'property' : 'identifier',
          raw,
          output: raw,
          line: tokLine,
          column: tokCol,
        });
      } else if (Object.prototype.hasOwnProperty.call(KEYWORD_MAP, raw)) {
        const mapped =
          raw === 'desimal' && nextChar === '(' ? 'parseFloat' : KEYWORD_MAP[raw];
        out += mapped;
        keywordsReplaced++;
        prevSigToken = raw;
        tokens.push({
          type: 'keyword',
          raw,
          output: mapped,
          line: tokLine,
          column: tokCol,
        });
      } else {
        out += raw;
        prevSigToken = raw;
        tokens.push({
          type: 'identifier',
          raw,
          output: raw,
          line: tokLine,
          column: tokCol,
        });
      }
      continue;
    }

    // Numbers (integers & floating-point decimals)
    if (isDigit(ch)) {
      const tokLine = line;
      const tokCol = col;
      const start = i;
      let dotCount = 0;
      while (
        i < source.length &&
        (isDigit(source[i]) ||
          source[i] === '.' ||
          source[i] === '_' ||
          source[i] === 'x' ||
          source[i] === 'X' ||
          source[i] === 'b' ||
          source[i] === 'B' ||
          (source[i] >= 'a' && source[i] <= 'f') ||
          (source[i] >= 'A' && source[i] <= 'F'))
      ) {
        if (source[i] === '.') {
          dotCount++;
          if (dotCount > 1) {
            throw new KenyahSyntaxError(
              'Format angka desimal tidak valid (lebih dari satu titik desimal)',
              tokLine,
              tokCol,
              filename,
              'InvalidNumberLiteral'
            );
          }
        }
        advance();
      }
      const raw = source.slice(start, i);
      out += raw;
      prevSigToken = raw;
      tokens.push({ type: 'number', raw, output: raw, line: tokLine, column: tokCol });
      continue;
    }

    // Optional chaining `?.`
    if (ch === '?' && source[i + 1] === '.') {
      const tokLine = line;
      const tokCol = col;
      advance(2);
      out += '?.';
      prevSigToken = '?.';
      tokens.push({ type: 'punctuation', raw: '?.', output: '?.', line: tokLine, column: tokCol });
      continue;
    }

    // Punctuation & operators
    const tokLine = line;
    const tokCol = col;
    if (ch === '{') braceDepth++;
    if (ch === '}' && braceDepth > 0) braceDepth--;
    advance();
    out += ch;
    prevSigToken = ch;
    tokens.push({ type: 'punctuation', raw: ch, output: ch, line: tokLine, column: tokCol });
  }

  return {
    code: out,
    tokens,
    endIndex: i,
    endLine: line,
    endCol: col,
    keywordsReplaced,
    preservedProperties,
    stringsCount,
    commentsCount,
  };
}

export function analyzeAndTranspile(
  source: string,
  options: { filename?: string } = {}
): TranspileAnalysis {
  try {
    if (typeof source !== 'string') {
      throw new KenyahTranspilerError(
        'Source code harus berupa string.',
        1,
        1,
        'InvalidInputType',
        options.filename
      );
    }

    const result = scanChunk(source, 0, 1, 1, false, options.filename);
    const lines = source.length === 0 ? 0 : source.split(/\r\n|\r|\n/).length;

    return {
      code: result.code,
      tokens: result.tokens,
      stats: {
        keywordsReplaced: result.keywordsReplaced,
        preservedProperties: result.preservedProperties,
        stringsCount: result.stringsCount,
        commentsCount: result.commentsCount,
        lines,
      },
    };
  } catch (error) {
    if (
      error instanceof KenyahSyntaxError ||
      error instanceof KenyahTranspilerError
    ) {
      throw error;
    }
    if (error instanceof SyntaxError) {
      throw new KenyahSyntaxError(
        error.message,
        1,
        1,
        options.filename,
        'SyntaxError'
      );
    }
    throw new KenyahTranspilerError(
      error instanceof Error ? error.message : String(error),
      1,
      1,
      'UnexpectedTranspilerError',
      options.filename
    );
  }
}

export function transpile(
  source: string,
  options: { filename?: string } = {}
): string {
  try {
    return analyzeAndTranspile(source, options).code;
  } catch (error) {
    if (
      error instanceof KenyahSyntaxError ||
      error instanceof KenyahTranspilerError
    ) {
      throw error;
    }
    if (error instanceof SyntaxError) {
      throw new KenyahSyntaxError(
        error.message,
        1,
        1,
        options.filename,
        'SyntaxError'
      );
    }
    throw new KenyahTranspilerError(
      error instanceof Error ? error.message : String(error),
      1,
      1,
      'UnexpectedTranspilerError',
      options.filename
    );
  }
}

export interface RunOptions {
  filename?: string;
  console?: Pick<Console, 'log'> & Partial<Console>;
}

export interface RunResult {
  transpiledCode: string;
  durationMs: number;
}

export function run(source: string, options: RunOptions = {}): RunResult {
  const start = typeof performance !== 'undefined' ? performance.now() : Date.now();
  const transpiledCode = transpile(source, { filename: options.filename });
  const targetConsole = options.console ?? globalThis.console;

  const executor = new Function('console', `"use strict";\n${transpiledCode}`);
  executor(targetConsole);

  const end = typeof performance !== 'undefined' ? performance.now() : Date.now();
  return {
    transpiledCode,
    durationMs: Math.max(0, Number((end - start).toFixed(2))),
  };
}
