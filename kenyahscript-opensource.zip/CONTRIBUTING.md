# Contributing to KenyahScript

Terima kasih telah tertarik berkontribusi pada **KenyahScript**!

## Struktur Proyek

- `src/transpiler.ts` — Lexer, transpiler `.kny` → `.js`, error diagnostik, dan runtime `run()`.
- `src/utils/formatKenyah.ts` — Auto-formatter kode sumber KenyahScript.
- `src/npmEntry.ts` — Entry point API modul npm `kenyahscript`.
- `bin/kny.ts` — CLI `kny` (`run`, `build`, `format`).
- `scripts/build.ts` — Script build bundle JavaScript & deklarasi tipe `.d.ts` ke `dist/`.
- `editors/vscode-kenyahscript/` — Ekstensi VS Code / Cursor (grammar, konfigurasi bahasa, snippets).
- `test/` — Unit test menggunakan `node:test`.

## Verifikasi Lokal

```bash
npm run lint
npm test
npm run build
node dist/cli.js run examples/halo.kny
```
