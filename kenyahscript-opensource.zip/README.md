# KenyahScript (`.kny`)

**KenyahScript** adalah bahasa pemrograman bergaya **JavaScript** yang terinspirasi dari kosakata **Bahasa Kenyah**, dirancang murni untuk **Node.js / JavaScript via npm** (0 dependensi runtime) dan dilengkapi ekstensi **code editor** (VS Code, Cursor, VSCodium, Windsurf).

## Instalasi via npm

```bash
# Pasang secara global untuk memakai CLI `kny` di terminal
npm install -g kenyahscript

# Atau pasang di proyek JavaScript / TypeScript Anda
npm install kenyahscript
```

Atau jalankan langsung tanpa instalasi global:

```bash
npx kenyahscript run examples/halo.kny
```

## Penggunaan CLI (`kny`)

```bash
# Menjalankan file .kny
kny run program.kny

# Mengompilasi file .kny ke JavaScript (.js)
kny build program.kny -o program.js

# Memformat kode sumber .kny secara otomatis
kny format program.kny --write

# Cek versi & bantuan
kny --version
kny --help
```

## Penggunaan di JavaScript / TypeScript

```ts
import { transpile, run, formatKenyahScript } from 'kenyahscript';

const kode = `
ti nama = "Tuyang";
desimal nilai = 9.5;
ti aktif = teneng;

boq (aktif) {
  tulis(\`Tabe, ${nama}! Nilai: ${nilai}\`);
}
`;

const jsOutput = transpile(kode, { filename: 'halo.kny' });
run(kode);
```

## Daftar Keyword KenyahScript → JavaScript

| KenyahScript | JavaScript | Keterangan |
| --- | --- | --- |
| `ti` | `let` | Deklarasi variabel lokal |
| `tetap` | `const` | Deklarasi konstanta |
| `desimal` | `let` / `parseFloat` | Deklarasi bilangan desimal atau konversi |
| `gayeng` | `function` | Deklarasi fungsi |
| `ulek` | `return` | Mengembalikan nilai dari fungsi |
| `boq` | `if` | Percabangan kondisional |
| `lain` | `else` | Blok alternatif |
| `ulang` | `for` | Perulangan `for` |
| `selama` | `while` | Perulangan `while` |
| `tulis` | `console.log` | Cetak ke konsol |
| `teneng` | `true` | Boolean benar |
| `bohong` / `sala` | `false` | Boolean salah |
| `kosong` | `null` | Nilai kosong |

## Pasang Ekstensi di Code Editor (VS Code / Cursor)

Ekstensi syntax highlighting TextMate, bracket matching, dan snippets tersedia di [`editors/vscode-kenyahscript`](./editors/vscode-kenyahscript):

```bash
cd editors/vscode-kenyahscript
npx @vscode/vsce package
code --install-extension kenyahscript-1.0.0.vsix
```

## Pengembangan & Publish ke npm

```bash
npm install
npm run lint
npm test
npm run build
npm publish --access public
```

## Lisensi

[MIT](./LICENSE)
