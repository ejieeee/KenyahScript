import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { runCli } from '../bin/kny';

test('CLI kny run mengeksekusi examples/halo.kny dengan exit code 0', () => {
  const out: string[] = [];
  const err: string[] = [];
  const code = runCli(['run', 'examples/halo.kny'], {
    stdout: (m) => out.push(m),
    stderr: (m) => err.push(m),
  });

  assert.equal(code, 0);
  assert.deepEqual(err, []);
  assert.deepEqual(out, [
    'Tabe, Tuyang! Boq teneng, mari belajar ngoding.',
    'Hitungan ke-1',
    'Hitungan ke-2',
    'Hitungan ke-3',
  ]);
});

test('CLI kny build menulis file JS keluaran dengan opsi -o', () => {
  const tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), 'kny-cli-'));
  const outFile = path.join(tmpDir, 'halo.js');
  const out: string[] = [];
  const err: string[] = [];

  try {
    const code = runCli(['build', 'examples/halo.kny', '-o', outFile], {
      stdout: (m) => out.push(m),
      stderr: (m) => err.push(m),
    });

    assert.equal(code, 0);
    assert.deepEqual(err, []);
    const built = fs.readFileSync(outFile, 'utf8');
    assert.match(built, /\blet nama = "Tuyang";/);
    assert.match(built, /\bfunction sapa\(orang\)/);
  } finally {
    fs.rmSync(tmpDir, { recursive: true, force: true });
  }
});

test('CLI kny format mengembalikan kode yang terformat rapi', () => {
  const tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), 'kny-fmt-'));
  const srcFile = path.join(tmpDir, 'messy.kny');
  fs.writeFileSync(srcFile, 'ti   x=10;\nboq(x>5){tulis(x);}', 'utf8');

  const out: string[] = [];
  const err: string[] = [];
  try {
    const code = runCli(['format', srcFile], {
      stdout: (m) => out.push(m),
      stderr: (m) => err.push(m),
    });

    assert.equal(code, 0);
    assert.deepEqual(err, []);
    assert.match(out[0], /ti x = 10;/);
    assert.match(out[0], /boq \(x > 5\)/);
  } finally {
    fs.rmSync(tmpDir, { recursive: true, force: true });
  }
});

test('CLI mengembalikan exit code 1 untuk file yang tidak ditemukan', () => {
  const out: string[] = [];
  const err: string[] = [];
  const code = runCli(['run', 'tidak_ada.kny'], {
    stdout: (m) => out.push(m),
    stderr: (m) => err.push(m),
  });

  assert.equal(code, 1);
  assert.match(err[0], /File tidak ditemukan/);
});
