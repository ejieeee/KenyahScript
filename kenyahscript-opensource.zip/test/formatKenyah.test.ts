import test from 'node:test';
import assert from 'node:assert/strict';
import { formatKenyahScript } from '../src/utils/formatKenyah';
import { run } from '../src/transpiler';

test('menstandarkan indentasi dan spasi pada kode KenyahScript berantakan', () => {
  const messy = `
ti   x=10;
desimal   pi=3.14;
gayeng tambah(a,b){
boq(a>0&&teneng){
ulek a+b;
}lain{
ulek 0;
}
}
ulang(ti i=0;i<2;i++){
tulis(tambah(x,i));
}
`;

  const formatted = formatKenyahScript(messy);
  const expected = [
    'ti x = 10;',
    'desimal pi = 3.14;',
    'gayeng tambah(a, b) {',
    '  boq (a > 0 && teneng) {',
    '    ulek a + b;',
    '  } lain {',
    '    ulek 0;',
    '  }',
    '}',
    'ulang (ti i = 0; i < 2; i++) {',
    '  tulis(tambah(x, i));',
    '}',
  ].join('\n');

  assert.equal(formatted, expected);
  // Idempotent
  assert.equal(formatKenyahScript(formatted), expected);

  // Valid and runnable after formatting
  const logs: string[] = [];
  run(formatted, {
    console: { log: (...args: unknown[]) => logs.push(args.map(String).join(' ')) },
  });
  assert.deepEqual(logs, ['10', '11']);
});

test('tidak mengubah isi string literal, komentar, properti titik, dan angka negatif unary', () => {
  const input = `//   komentar:   a+b=c
ti  pesan="a+b=c,boq(x){}";
ti  neg=-5;
ti  obj={info:"ok",ulang:2};
tulis(obj.ulang);`;

  const formatted = formatKenyahScript(input);
  assert.ok(formatted.includes('//   komentar:   a+b=c'));
  assert.ok(formatted.includes('ti pesan = "a+b=c,boq(x){}";'));
  assert.ok(formatted.includes('ti neg = -5;'));
  assert.ok(formatted.includes('ti obj = { info: "ok", ulang: 2 };'));
  assert.ok(formatted.includes('tulis(obj.ulang);'));
});

test('menghapus baris kosong berlebih menjadi maksimal satu baris kosong', () => {
  const input = 'ti a=1;\n\n\n\nti b=2;\n\n';
  assert.equal(formatKenyahScript(input), 'ti a = 1;\n\nti b = 2;');
});
