import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import {
  transpile,
  run,
  analyzeAndTranspile,
  KenyahSyntaxError,
  KenyahTranspilerError,
} from '../src/transpiler';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

test('mentranspilasi semua keyword dasar dengan benar', () => {
  const input = `
    ti x = 10;
    ti aktif = teneng;
    ti selesai = bohong;
    desimal pi = 3.14;
    ti konversi = desimal("12.75");
    gayeng tambah(a, b) {
      ulek a + b;
    }
    boq (aktif) {
      tulis(tambah(x, 5));
    } lain {
      tulis("Tidak aktif");
    }
    ulang (ti i = 0; i < 2; i++) {
      tulis(i);
    }
  `;

  const output = transpile(input);
  assert.match(output, /\blet x = 10;/);
  assert.match(output, /\blet aktif = true;/);
  assert.match(output, /\blet selesai = false;/);
  assert.match(output, /\blet pi = 3\.14;/);
  assert.match(output, /\blet konversi = parseFloat\("12\.75"\);/);
  assert.match(output, /\bfunction tambah\(a, b\)/);
  assert.match(output, /\breturn a \+ b;/);
  assert.match(output, /\bif \(aktif\)/);
  assert.match(output, /\belse \{/);
  assert.match(output, /\bconsole\.log\(tambah\(x, 5\)\);/);
  assert.match(output, /\bfor \(let i = 0;/);
});

test('menjalankan program dengan desimal, teneng, dan bohong dengan hasil tepat', () => {
  const input = `
    desimal harga = 19.5;
    desimal pajak = desimal("2.25");
    ti benar = teneng;
    ti palsu = bohong;
    boq (benar && !palsu) {
      tulis(harga + pajak);
    }
  `;
  const logs: string[] = [];
  run(input, {
    filename: 'desimal.kny',
    console: { log: (...args: unknown[]) => logs.push(args.map(String).join(' ')) },
  });
  assert.deepEqual(logs, ['21.75']);
});

test('tidak mengubah keyword di dalam string literal dan komentar', () => {
  const input = `
    // ti gayeng boq teneng desimal bohong
    /* ulek lain ulang tulis desimal bohong */
    ti pesan = "Boq teneng, ti ulek gayeng desimal bohong!";
    ti escape = "Dia berkata \\"teneng\\" dan \\"bohong\\" lalu pergi";
  `;

  const output = transpile(input);
  assert.ok(output.includes('// ti gayeng boq teneng desimal bohong'));
  assert.ok(output.includes('/* ulek lain ulang tulis desimal bohong */'));
  assert.ok(output.includes('"Boq teneng, ti ulek gayeng desimal bohong!"'));
  assert.ok(output.includes('"Dia berkata \\"teneng\\" dan \\"bohong\\" lalu pergi"'));
});

test('tidak mengubah nama properti setelah titik (.)', () => {
  const input = `ti obj = { info: "ok" }; tulis(obj.ulang); tulis(obj.desimal); tulis(obj.bohong);`;
  const output = transpile(input);
  assert.ok(output.includes('obj.ulang'));
  assert.ok(output.includes('obj.desimal'));
  assert.ok(output.includes('obj.bohong'));
  assert.ok(!output.includes('obj.for'));
});

test('tidak mengubah key object literal maupun optional chaining', () => {
  const input = `ti data = { ulang: 3, boq: teneng, bohong: sala, desimal: 1.5 }; tulis(data?.ulang);`;
  const output = transpile(input);
  assert.ok(output.includes('{ ulang: 3, boq: true, bohong: false, desimal: 1.5 }'));
  assert.ok(output.includes('data?.ulang'));
});

test('mentranspilasi ekspresi di dalam template literal ${...}', () => {
  const input = 'ti n = 2; tulis(`Nilai: ${boqTeneng(n)} dan ${n + 1}`);';
  const output = transpile(input);
  assert.ok(output.includes('console.log(`Nilai: ${boqTeneng(n)} dan ${n + 1}`);'));

  const exprInput = 'ti n = 2; tulis(`Aktif: ${teneng ? "ya" : bohong}`);';
  const exprOutput = transpile(exprInput);
  assert.ok(exprOutput.includes('`Aktif: ${true ? "ya" : false}`'));
});

test('melempar KenyahSyntaxError (extends SyntaxError) beserta baris dan nature jika string tidak ditutup', () => {
  assert.throws(
    () => transpile('ti a = 1;\nti x = "belum tutup;'),
    (err: unknown) => {
      assert.ok(err instanceof SyntaxError);
      assert.ok(err instanceof KenyahSyntaxError);
      assert.equal(err.line, 2);
      assert.equal(err.nature, 'UnclosedStringLiteral');
      return true;
    }
  );
});

test('melempar KenyahSyntaxError jika format angka desimal memiliki lebih dari satu titik', () => {
  assert.throws(
    () => transpile('desimal salah = 3.14.15;'),
    (err: unknown) => {
      assert.ok(err instanceof SyntaxError);
      assert.ok(err instanceof KenyahSyntaxError);
      assert.equal(err.line, 1);
      assert.equal(err.nature, 'InvalidNumberLiteral');
      return true;
    }
  );
});

test('melempar KenyahSyntaxError jika komentar blok tidak ditutup', () => {
  assert.throws(
    () => transpile('/* belum tutup'),
    (err: unknown) => {
      assert.ok(err instanceof SyntaxError);
      assert.ok(err instanceof KenyahSyntaxError);
      assert.equal(err.nature, 'UnclosedBlockComment');
      return true;
    }
  );
});

test('menangkap input non-string via try-catch dan melempar KenyahTranspilerError', () => {
  assert.throws(
    () => transpile(null as unknown as string),
    (err: unknown) => {
      assert.ok(err instanceof KenyahTranspilerError);
      assert.equal(err.line, 1);
      assert.equal(err.nature, 'InvalidInputType');
      return true;
    }
  );
});

test('menghitung statistik analisis token dengan akurat', () => {
  const analysis = analyzeAndTranspile('ti obj = { info: "boq" }; // ulang\ntulis(obj.ulang);');
  assert.equal(analysis.stats.keywordsReplaced, 2); // ti, tulis
  assert.equal(analysis.stats.preservedProperties, 1); // obj.ulang
  assert.equal(analysis.stats.stringsCount, 1);
  assert.equal(analysis.stats.commentsCount, 1);
});

test('menjalankan examples/halo.kny dan menghasilkan output yang sesuai', () => {
  const haloPath = path.resolve(__dirname, '../examples/halo.kny');
  const source = fs.readFileSync(haloPath, 'utf8');

  const logs: string[] = [];
  const fakeConsole = {
    log: (...args: unknown[]) => logs.push(args.join(' ')),
  };

  run(source, { filename: 'halo.kny', console: fakeConsole });

  assert.deepEqual(logs, [
    'Tabe, Tuyang! Boq teneng, mari belajar ngoding.',
    'Hitungan ke-1',
    'Hitungan ke-2',
    'Hitungan ke-3',
  ]);
});
