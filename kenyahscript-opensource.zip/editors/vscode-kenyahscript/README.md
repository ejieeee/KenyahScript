# KenyahScript (.kny) Editor Extension

Syntax highlighting, auto-closing brackets/comments, and code snippets for **KenyahScript (`.kny`)** in VS Code, Cursor, VSCodium, Windsurf, and any TextMate-compatible editor.

## Local Installation (VS Code / Cursor / VSCodium)

1. Package the extension as a `.vsix` archive:
   ```bash
   cd editors/vscode-kenyahscript
   npx @vscode/vsce package
   ```
2. Install into VS Code or Cursor:
   ```bash
   code --install-extension kenyahscript-1.0.0.vsix
   # or for Cursor:
   cursor --install-extension kenyahscript-1.0.0.vsix
   ```

Alternatively, symlink or copy this folder into `~/.vscode/extensions/kenyahscript-1.0.0` (or `~/.cursor/extensions/kenyahscript-1.0.0`) and reload the editor window.
